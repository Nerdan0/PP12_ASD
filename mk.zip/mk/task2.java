//ПП-12
//Бєтін Артур
//Вариант 2

import java.util.Scanner;

public class task2 {

public static void main(String args[]) {
int n, m;
int counterMax = 0;
int counterMin = 0;
Scanner scanner = new Scanner(System.in);
System.out.println("1 - ручное заполнение");
System.out.println("2 - автоматическое заполнение");
if (scanner.hasNextInt()) {
m = scanner.nextInt();
if (m < 1 && m > 2) {
System.out.println("попробуйте ещё раз");
return;
} else {
if (m == 1) {

System.out.println("Сколько игр?");
if (scanner.hasNextInt()) {
n = scanner.nextInt();
if (n <= 0 || n > 100) {
System.out.println("Попробуйте ещё раз");
return;
}
} else {
System.out.println("Попробуйте ещё раз");
return;
}
double[][] game = new double[n][3];
for (int i = 0; i < n; i++) {
System.out.println("Введите результат игры " + (i + 1));
if (scanner.hasNextInt()) {
game[i][0] = scanner.nextInt();
} else {
System.out.println("Попробуйте ещё раз");
return;
}
game[0][1] = game[0][0];
game[0][2] = game[0][0];
if (i > 0 && game[i][0] > game[i - 1][1]) {
game[i][1] = game[i][0];
counterMax +=1;
} else if (i == 0) {
} else {
game[i][1] = game[i - 1][1];
}
if (i > 0 && game[i][0] < game[i - 1][2]) {
game[i][2] = game[i][0];
counterMin += 1;
} else if (i == 0) {
} else {
game[i][2] = game[i - 1][2];
}
}
for (int i = 0; i < n; i++) {
System.out.println(String.format(" %d | %4.0f | %4.0f | %4.0f ", i + 1, game[i][0], game[i][1], game[i][2]));
}
System.out.println("было "+counterMax+" увеличений, та "+counterMin+" уменьшений.");
}
else if(m==2){
n=10;
double[][] game = new double[n][3];
for (int i = 0; i < n; i++) {
game[i][0] = Math.random()*1000;

game[0][1] = game[0][0];
game[0][2] = game[0][0];
if (i > 0 && game[i][0] > game[i - 1][1]) {
game[i][1] = game[i][0];
counterMax +=1;
} else if (i == 0) {
} else {
game[i][1] = game[i - 1][1];
}
if (i > 0 && game[i][0] < game[i - 1][2]) {
game[i][2] = game[i][0];
counterMin += 1;
} else if (i == 0) {
} else {
game[i][2] = game[i - 1][2];
}
}
for (int i = 0; i < n; i++) {
System.out.println(String.format(" %d | %4.0f | %4.0f | %4.0f ", i + 1, game[i][0], game[i][1], game[i][2]));
}
System.out.println("было "+counterMax+" увеличений, и "+counterMin+" уменьшений.");
}
}
}
else{System.out.println("Попробуйте ещё раз");}
}
}
//смилуйтесь