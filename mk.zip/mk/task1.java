import java.util.Random;
import java.util.Scanner;
class task1 {
 public static void void1(){
    int size=0;
    int q=0;
    int a=0,b=0;

    Random rnd = new Random();

    System.out.println("Введите размер ");
    Scanner e = new Scanner(System.in);
    if (e.hasNextInt()) { 
        size =e.nextInt(); 

    } else {
        System.out.println("Try again");
        System.exit(0);
    }
    int[][] matrix = new int[size][size];
    int[][] array = new int[size][size];

    System.out.println("Заполнить вручную 1 , случайно 0 ");
    Scanner g = new Scanner(System.in);
    if (g.hasNextInt()) {
        q = g.nextInt();

    } else {
        System.out.println("Try again");
        System.exit(0);
    }

    switch (q) {
        case 0:
            for (int i=0;i < matrix.length;i++) {
                for (int j=0;j < matrix[i].length;j++) {
                    matrix[i][j]=rnd.nextInt(200) - 100;}}


            for (int i=0;i < matrix.length;i++,System.out.println()) {
                for (int j=0;j < matrix[i].length;j++) {
                    System.out.print(matrix[i][j]+" ");}}

            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix.length; j++) {
                    if (i == j) {
                        a += matrix[i][j];
                    }
                    if (i == (matrix.length - j-1)) {
                        b += matrix[i][j];
                    }
                }
            }
            int c=Math.abs(a-b);
            System.out.println("Абсолютна різниця "+c);
        break;
        case 1:
            Scanner z = new Scanner(System.in);
            System.out.println("Заполните матрицу ");
            for (int i = 0; i < array.length; i++) {
                for (int j = 0; j < array[i].length; j++) {
                    System.out.print("Введите елемент  arr[" + i + "][" + j + "]:");
                    array[i][j] = z.nextInt();
                }
            }
            z.close();

            for (int i=0;i < array.length;i++,System.out.println()) {
                for (int j=0;j < array[i].length;j++) {
                    System.out.print(array[i][j]+" ");}}

            break;
        default:
            System.out.print("");

    }
 }
 public static void main(String args[]) {
    void1();    
    }
}